// Efejohn Erdem
//Rock, Paper, Scissors project


import java.util.*;
import java.util.Random.*;

public class rockpaperscissors
{// begin class

public static void main (String [] args)
{// begin main

// explains to user the purpose of the program
System.out.println(" Hi the purpose of this program is to serve as a rock, paper, scissor game\n with the computer against the user. if user chooses rock and computer chooses\n scissors, user wins. if user chooses scissors and computer chooses rock\n the computer wins. if the user picks paper and the computer picks\n scissors the computer wins. If the user picks scissors and computer\n picks paper, user wins. If the user picks paper and the computer picks rock\n the user wins. If user picks rock and computer picks paper, the computer wins.\n These are how the rules will follow. ");
System.out.println();

Scanner keyboard = new Scanner(System.in);
Random randomnum = new Random();

int computer = 0;
int user = 0;
int computerturn;
int userturn;

System.out.println("  First we will allow the computer to make a play and then the user ");

/* goes into the computer turn method with "computer" variable argument being placed in the method, 
once value is returned, it will store that vlaue into the "computerturn" variable */
computerturn = computermove(computer);
System.out.println();
System.out.println(" Now awaiting for the users turn ");

/* calls on usermove method with "user" variable argument being placed in the method, once value is
 returned, it will then store that value in the "userturn" variable */
userturn = usermove(user);

// goes into a void method where it brings both values in the computerturn, and userturn variable.
DisplayResults(computerturn,userturn);

}// end main method



//opens "computermove" method header 
public static int computermove(int computersmove)
{// begin method

// generates random number 
Random randomnum = new Random();

 computersmove = 0;
 
//random number generated is then stored in "computersmove"
computersmove = randomnum.nextInt(3)+1;

//returns "computersmove" variable and stores value in another method
return computersmove;

}// end computersmove domain



// opens "usermove" method header
public static int usermove(int usersmove)
{// begin method

usersmove = 0;

//scanner used for user input
Scanner keyboard = new Scanner(System.in);

System.out.println(" User, please enter 1 for rock, 2 for paper\n and 3 for scissors: ");

//ask user to input a number to pick rock, paper, or scissors as a choice of their play
usersmove = keyboard.nextInt();

/*if user inputs a invalid number(number greater than 3 or number less than 1), 
the program will ask the user to input in another number that is 1, 2, or 3 */

while((usersmove < 1 || usersmove > 3)){// begin while
System.out.println(" Please enter one of the valid numbers mentioned\n previously above, numbers 1 for rock, number 2 for paper\n or number 3 for scissors: ");
usersmove = keyboard.nextInt();
}// end while loop

// returns user input
return usersmove;

}// end method


//Opens the "DisplayResults" method header 
public static void DisplayResults(int compturn,int userinput)
{// begin method

//  Scanner is for user input
Scanner keyboard = new Scanner(System.in);

// for random number generator
Random randomnum = new Random();

char play;

do{// begin do

/* This section of if then statements is used to determine what the computer has chosen 
and whatever they have chosen the program displays it to the user what the computer chose*/
if(compturn == 1){// begin if
System.out.println(" computer chooses rock ");
System.out.println();
}// end if 
else
if(compturn == 2){// begin if
System.out.println(" computer chooses paper ");
System.out.println();
}// end if
else
if(compturn == 3){// begin if
System.out.println(" computer chooses scissors ");
System.out.println();
}// end if

/*if the user and computer have chosen the same numbers, then there is a draw
and the while statement generate a new number for the 
computer and ask the user to input in a new number 
*/
while(userinput == compturn){// begin while
System.out.println(" User and computer have a draw, another round must be played again to determine\n a winner ");
compturn = randomnum.nextInt(3)+1;
System.out.println("User, please enter 1 for rock,\n 2 for paper\n or 3 for Scissors ");
userinput = keyboard.nextInt();

// if user input is less than 1 or greater than 3, program asks user to enter a number that is valid
while(userinput < 1 || userinput > 3){// begin inner while
System.out.println("That is an invalid number, please enter number 1 for rock, number 2 for paper\n or number 3 for scissors: ");
userinput = keyboard.nextInt();

}// end inner while
if(compturn == 1){// begin if
System.out.println(" computer chooses rock ");
System.out.println();
}// end if 
else
if(compturn == 2){// begin if
System.out.println(" computer chooses paper ");
System.out.println();
}// end if
else
if(compturn == 3){// begin if
System.out.println(" computer chooses scissors ");
System.out.println();
}// end if

}// end while

/*In these set of if statements, the program examines to see whether the user or computer has won
depedning on the input both players have put in. If the user choice of depending on what they chose
beats what the computer has chosen, the user wins, if the other way around the computer wins and
a message is displayed in the print statement saying what has beat what, for example 
("rock smashes the scissors"), as shown in one of the println statements seen below.
*/

if(userinput == 3 && compturn == 1){// begin if
System.out.println("The rock smashes the scissors ");
System.out.println(" Computer has won the round because rock beats scissors! ");
}// end if
else
if(userinput == 1 && compturn == 3){// begin if
System.out.println("The rock smashes the scissors ");
System.out.println(" User has won the round because rock beats scissors! ");
}// end if

else
if(userinput == 2 && compturn == 3){// begin if
System.out.println("The scissors cuts the paper ");
System.out.println(" Computer has won because scissors beats paper! ");
}// end if
else
if(userinput == 3 && compturn == 2){// begin if
System.out.println("The scissors cuts the paper ");
System.out.println(" User has won because scissors beats paper! ");
}// end if
else
if(userinput == 1 && compturn == 2){// begin if
System.out.println("The paper wraps the rock ");
System.out.println(" Computer has won because paper beats rock! ");
}// end if
else
if(userinput == 2 && compturn == 1){// begin if
System.out.println("The paper wraps the rock ");
System.out.println(" User has won because paper beats rock! ");
}// end if



System.out.println("If you would like to play again, please enter yes or no: ");
play = keyboard.next().charAt(0);

//asks user if they would like to play again, if user enters 1, that means no, if 0 then that means no
if((play == 'y') || (play == 'Y')){// begin if
compturn = randomnum.nextInt(3)+1;
System.out.println("please enter a number again of 1 for rock, 2 for paper\n or 3 for scissors:");
userinput = keyboard.nextInt();
while(userinput <1 || userinput > 3)
{//begin while
///if user input number less than 1 or greater than 3, program asks user to enter number that is valid
System.out.println("That is an invalid number, please enter number 1 for rock, number 2 for paper\n or number 3 for scissors: ");
userinput = keyboard.nextInt();
}// end while
}// end if

/*this do while loop excutes again if the user enters the number'1' to play another round, if user 
enters '0' then that means no meaing the user does not want to play again and the program exits out
the do while loop and exits out the method. */
}// end while
while((play == 'y') || (play == 'Y'));

}// end void method


}// end class