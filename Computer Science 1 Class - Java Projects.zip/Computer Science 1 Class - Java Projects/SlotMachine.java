// Efejohn Erdem
// October, 30, 2019
//Project # 2 - Slot Machine program - functions as a virtual slot machine for users to play with

//imports Scanner
import java.util.*;

//imports random number generator
import java.util.Random.*;


public class SlotMachine
{// begin class

public static void main (String [] args)
{// begin main

//creates canner for input
Scanner keyboard = new Scanner(System.in);
//random generator
Random rand = new Random();

// variable used for program
int userinput, moneyinput, count, wordgenerator;
int moneyentered = 0;
int moneywon = 0;
char playagain;
String word = " ";
String word1 = " ";
String word2 = " ";
String word3 = " ";
int list = 3;

//Explains to user purpose of the program
System.out.println("Hi the purpose of this program is to function as a virtual slot machine where\n the user will bet money into the machine to play  and the program will then display\n a set of random words. If however many of the random words match,\n the user wins  the amount they put in times 2 if two of the\nwords match or wins the amount he put in times 3 if the user \n gets all three words match with the current round the user plays.\n If none of the words match, the user wins 0 dollars.\n user can not bet more money than they have brung total\n and if amount of money user has\n left is 0 dollars, user can not play anymore.");

//asks user to input the total amount of money they are bringing with them
System.out.println("To start the slot machine program off, please enter the amount of money\n you are going bring total: ");
userinput = keyboard.nextInt();



do{// begin do loop

// asks user to input the amount of money they would like to input for the round
System.out.println(" How much money are you going to put in to play? ");
moneyinput = keyboard.nextInt();

//tracks the toal amount of money entered by adding moneyinput to moneyentered variable each iteration
moneyentered += moneyinput;

/*checks to see if user tries to play with more money that exceeds the amount they start off with,
if they do, program lets the user know and asks user to try again*/
while (moneyinput>userinput){
System.out.println("you are betting more than you have. Please try again ");

//asks user to input amount they are willing to play, again
moneyinput = keyboard.nextInt();
}// end while loop

// for loop used to print out the three random words
for(count = 1; count<=list; count++)
{// begin inner for loop

//generates random number from 0 to 5 then adds value of 1 to the number
wordgenerator = rand.nextInt(6)+1;


switch(wordgenerator){

// sets numbers equal to the words 
case 0:
word = (" ");
break;

case 1:
// has the "word" variable set to word strings for each number that could be generated randomly
word = ("Cherries ");
System.out.print(word);
break;

case 2:
word = (" Oranges ");

System.out.print(word);

break;

case 3:
word = (" Plums ");

System.out.print(word);

break;

case 4:
word = (" Bells ");

System.out.print(word);

break;

case 5:
word = (" Melons ");

System.out.print(word);

break;

case 6:
word = (" Bars ");

System.out.print(word);
break;

default:

}// end switch statement

//prints out extra line
System.out.println();

//when counter equals 1 they set the first word to the variable "word1"
if(count == 1){
word1 = word;
}
else

//when counter equals 2 they set the first word to the variable "word2"
if(count == 2){
word2 = word;
}
else

//when counter equals 3 they set the first word to the variable "word3"
if(count == 3){
word3 = word;
}


}// end inner for loop

//prints out extra line
System.out.println();



/** In the group of if statments below in the program, it compares the words to one another to see if any
of the words match each other. If they do, the program tells the user how much money they have
won from that current round, adds that amount they won to their overall amount of dollars they
had in the begining and asks user to play again if they wish to. The user then types in "yes"
or "no" if they wish to play again or not. The program also counts and adds up the amount of money 
the user keeps entering overall.
*/
if((word1 != word2) && (word1 != word3) && (word2 != word3)){
System.out.println(" You have won $0 dollars ");
userinput = userinput - moneyinput;
System.out.println(" you have not won any money, you now have left "+userinput+" dollars ");
}// end if
else 

if ((word1 == word2) && (word1 != word3) || (word1!= word2) && (word1 == word3) || (word2 == word3) && (word2 != word1)){
System.out.println(" congrats, you have won "+(moneyinput*2)+" dollars");
moneywon += (moneyinput*2);
userinput = (userinput - moneyinput +(moneyinput*2));
System.out.println(" you now have "+userinput+" dollars left ");
}// end if 

else

if ((word1 == word2) && (word1 == word3) && (word2 == word3)){
   System.out.println(" congrats you got all three words the same. You have won "+(moneyinput*3)+" dollars ");
   moneywon+= (moneyinput*3);
   userinput = (userinput - moneyinput + (moneyinput *3));
   System.out.println(" you now have "+userinput+" dollars left ");
}// end if

System.out.println("would you like to play again? enter yes or no.  ");
playagain = keyboard.next().charAt(0);
// gets "yes" or "no" input from user

// if the amount of money the user has left(userinput variable) is equal to 0, user can not play anymore
if(userinput == 0)
{// begin if loop
System.out.println(" Sorry, you do not have any more money to play with ");

//print out extra line for space
System.out.println();

}// end if loop

}// end do loop

/*while playagain variable has the letter 'y' stored from user inputting "yes",and user input does not equal zero, the program will run again 
*/
 while((playagain == 'y') && (userinput!=0)); 


/* program tells user amount of dollars left total, total dollars entered into slot machine and
the amount of dollars the user has won total*/
System.out.println(" Thank you for playing! You have left "+userinput+" dollars total, you have entered "+moneyentered+" dollars total,\n and have won "+moneywon+" dollars total.");











}// end main

}// end class