// Efejohn Erdem
// calculator project- calculate the value of two single digit numbers using a arithmetic expression
//october, 1st, 2019

import java.util.*;
// imports the java scanner 
import java.lang.Math;
// java.lang.math contains the method to perofrm basic number operations

public class calculatorproject
{//begin main

public static void main (String [] args)
{// begin class

// system will display a message  explaining to the user what the function of the program is to do
System.out.print(" hi there, the purpose of this program is to function as a calculator that will do all your calculations\n on two single-digit numbers ranging from 0-9, and use your selected arithmetic expression of choice\n ranging from +,-,*,/ or ^ that you would like to use for your two numbers ");

// variables number1 and number2 are both integer values. The output variable is a double value due to division of two numbers possibly coming out as a decimal
int number1;
int number2;
double output;


// variable operater is a char
char operator;


// create new scanner called keyboard for the program
Scanner keyboard = new Scanner(System.in);

// program obtains first number from the user, and stores it in the variable number1
System.out.print("\n\nto start off please enter your first number of choice you would like to use: ");
number1 = keyboard.nextInt();
// if the number the user inputs is not in between the numbers 1 to 9 range, the program will give exit out the system and ask user to run program again
if (number1<0 || number1>9){
System.out.print(" that is a invalid number, please try again");
System.exit(0);
}
 
 
 
// program obtains the second number from the user, and stores it in the variable number2
System.out.print("\nplease enter your second number of choice you would like to use: ");
number2 = keyboard.nextInt();

// if the number the user inputs is not in between the numbers 1 to 9 range, the program will exit out the system and ask user to run program again
if (number2<0 || number2>9){
System.out.print(" that is a invalid number, please try again");
System.exit(0);
}


// program will ask the user to input a expression and it will store it in the operator variable
System.out.print("\nnow please enter a arithmetic expression that you would like to use for your two entered digits of choice: +,-,*,/,^, ");
 operator = keyboard.next().charAt(0);
// if what the user enters as an expression does not equal +,-,*,/, and ^, the program will exit out and ask user to run program again
 if (operator != '+'){
if (operator != '-'){
if (operator != '*'){
if (operator != '/'){
if (operator != '^'){

System.out.print("invalid operator, please run and try again");
System.exit(0);
// program will system exit if invalid operator is input
}
}
}
}
}



// program uses case switch to see what case the number that the user inputted will match
switch (number1){
// use cases to determine what number the user inputted and print out that number to the user in word form

case 0:
System.out.print("zero ");

break;
// the break statement is used to close the switch case after the number is entered so it does not run all the different case statements and just the one of the number that was entered.

case 1:
System.out.print("one ");

break;

case 2:
System.out.print("two ");

break;

case 3:
System.out.print("three ");

break;

case 4:
System.out.print("four ");

break;

case 5:
System.out.print("five ");

break;

case 6:
System.out.print("six ");

break;

case 7:
System.out.print("seven ");

break;

case 8:
System.out.print("eight ");

break;

case 9:
System.out.print("nine ");

break;



}


// program uses case switch to see what case the expression that the user inputted will match
switch (operator){
// whatever expression is inputted, program prints out that expression in word form 
case '+' :
 
System.out.print("plus ");

break;
// the break statement is used to close the switch case after the number is entered so it does not run all the different case statements and just the one of the number that was entered.

case '-' :

System.out.print("minus ");


break;

case '*' :

System.out.print(" multiplied by ");


break;

case '/' :

System.out.print(" divided by, ");



break;

case '^' :
System.out.print(" raised by ");

break;
}


// program uses case switch to see what case the number that the user inputted will match
switch (number2){

case 0:
if (number2 == 0 && operator == '/'){
// if the second number equals zero that means its undefined becuase you can not divide a number by zero
System.out.print("  uh oh, sorry that is an undefined value, you can't divide a number by 0, please run and try again. ");
System.exit(0);
}
else

if(number2 == 0 && operator != '/'){
// if the second number is not equal to zero, that means the two numbers will be able to be divisible 
System.out.print("zero equals ");
}
break;
// the break statement is used to close the switch case after the number is entered so it does not run all the different case statements and just the one of the number that was entered.


// use cases to determine what number the user inputted and print out that number to the user in word form and set it as equals too as the second operator will be the last variable after the variable number1 and oeprator are displayed
case 1:
System.out.print(" one equals ");

break;
case 2:
System.out.print(" two equals ");

break;

case 3:
System.out.print(" three equals ");

break;

case 4:
System.out.print(" four equals ");

break;

case 5:
System.out.print(" five equals ");

break;

case 6:
System.out.print(" six equals ");

break;

case 7:
System.out.print(" seven equals ");

break;

case 8:
System.out.print(" eight equals ");

break;

case 9:
System.out.print(" nine equals ");

break;
}

// if the expression the user entered for the operator variable was +, then the program will add the two numbers and print out the output.
if (operator == '+'){
	output = number1 + number2;
	System.out.println(output);
}
// if the expression the user entered for the operator variable was -, then the program will subtract the two numbers and print out the output.

else if (operator == '-'){
	output = number1 - number2;
	System.out.println(output);
}


// if the expression the user entered for the operator variable was *, then the program will add the two numbers and print out the output.
else if (operator == '*'){
	output = number1 * number2;
	System.out.println(output);
}


// if the expression the user entered for the operator variable was /, then the program will divide the two numbers and print out the output.
// the double next to the number 2 is so that if the numbers that divide or not perfectly divisible, if will still print out the whole number even when it is a decimal
else if (operator == '/'){
	output = ((number1)/((double)number2));
	System.out.println(output);
}


// if the expression the user entered for the operator variable was ^, then the program will raise the power of one number to the second number and print out the output.
else if (operator == '^'){
	output = Math.pow(number1, number2);
// the math.pow will allow the program to raise the power of one number to the second umber
	System.out.print(output);
}



}// end main


}//end class



