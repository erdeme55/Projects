﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;

namespace CarRentalService
{
    public partial class Mainfrm : Form
    {

        
        DataSet carDataSet = new DataSet();
        carInventory carinventory = new carInventory();
        Car carinfo = new Car();
        
        private List<Car> carList = new List<Car>();

        public Mainfrm()
        {
            InitializeComponent();
            this.FormClosed += Mainfrm_FormClosing;
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void AddCars_Click(object sender, EventArgs e)
        {

            this.Hide();
            
             AddCars  addingvehicles = new AddCars();
            addingvehicles.Owner = this;
            addingvehicles.Show();
           
            
           
        }


        private void RentCar_Click(object sender, EventArgs e)
        {
            this.Hide();
            RentCar renting = new RentCar();
            renting.Show();
            
          
        }

        private void Mainfrm_Load(object sender, EventArgs e)
        {
            this.carDBTableTableAdapter.Fill(this.carDBDataSet.CarDBTable);


            DataTable carTable = carDatabase.loadFromCarDatabase();
            BindingSource bs = new BindingSource();
            bs.DataSource = carTable;

            CarInventoryDataGridView.DataSource = bs;

            searchCarCategory.DataSource = carDataSet.Tables["carTable"];
            searchCarCategory.DisplayMember = "CarCategory";  
            searchCarCategory.ValueMember = "CarCategory";

        }



        private void Mainfrm_FormClosing(object sender, FormClosedEventArgs e)
        {
            

        }



        private void CarInventoryList_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void DeleteCar_Click(object sender, EventArgs e)
        {
           
        }

        private void SaveData_Click(object sender, EventArgs e)
        {
            
        }

        private void CarInventoryList_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            



        }

        private void SearchBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            


        }

        private void SearchBox_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void CarSearch_TextChanged(object sender, EventArgs e)
        {


            

        }

        private void searchCategory_Click(object sender, EventArgs e)
        {
            carDatabase car = new carDatabase();

           // Console.WriteLine(searchCarCategory.SelectedItem.ToString());

            BindingSource bs = new BindingSource();
            bs.DataSource = car.searchCarDatabase(searchCarCategory.SelectedItem.ToString());
           
            CarInventoryDataGridView.DataSource = bs;





        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            carDatabase.RemoveRows(CarInventoryDataGridView);
            carDatabase carData = new carDatabase();
            carData.DeleteFromDatabase(CarInventoryDataGridView.CurrentRow);
            carinventory.RemoveCar(carinfo);
        }

        private void viewbtn_Click(object sender, EventArgs e)
        {
            
            if (CarInventoryDataGridView.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow carRow in CarInventoryDataGridView.SelectedRows)
                {
                    carDatabase.DisplaySelectedCarDetails(carRow);
                }
            }
        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
        }

        private void modbtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            ModifyCar mod = new ModifyCar();
            mod.Show();
        }
    }
    }
    

