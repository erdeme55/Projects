﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.SqlClient;



namespace CarRentalService
{
    
    public partial class AddCars : Form
    {
        OleDbConnection myConnection;
        DataSet carDataSet;
        OleDbDataAdapter myDataAdapter;
        DataTable carTable;
        carInventory carinventory = new carInventory();
        OleDbCommand carCommand;
        string carSQL;
        carDatabase carData = new carDatabase();

        public AddCars()
        {
            InitializeComponent();
            this.FormClosed += AddCars_FormClosing;
         
        }


        private void AddCars_FormClosing(object sender, FormClosedEventArgs e)
        {



        }


        private void AddCars_Load(object sender, EventArgs e)
        {
           

        }

        private void GoBack_Click(object sender, EventArgs e)
        {
           
            this.Close();
            
            Mainfrm goback = new Mainfrm();
            goback.Show();

            
        }


       

        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        private void StoreInfo_Click(object sender, EventArgs e)
        {

            

            if (CarCategorybox.Text == "") throw new ArgumentException("please input category");

            
            if (CarManufacturertxt.Text == "") throw new ArgumentException(" please input in a car make");

            
            if (ModelOfCartxt.Text == "") throw new ArgumentException(" please input in a car model");

            if (yeartxt.Text == "") throw new ArgumentException(" please input in a car year");

            if (milagetxt.Text == "") throw new ArgumentException(" please input in a car milage");

            if (rentalcosttxt.Text == "") throw new ArgumentException("please inout in a car rental cost");
          
            if (availabletxt.Text == "") throw new ArgumentException(" please input in a availability for vehicle");

          
            if (descriptiontxt.Text == "") throw new ArgumentException(" please input in a description for the vehicle");

            
            if (locationtxt.Text == "") throw new ArgumentException(" please input in where the vhicle is located");

            if (imagetxt.Text == "") throw new ArgumentException("please input in url of car image");
            

           

            Car car = new Car(CarCategorybox.Text, CarManufacturertxt.Text, ModelOfCartxt.Text, int.Parse(yeartxt.Text), double.Parse(milagetxt.Text), double.Parse(rentalcosttxt.Text), availabletxt.Text, descriptiontxt.Text, locationtxt.Text, imagetxt.Text);

            carData.addtoCarDatabase(car);
            carinventory.AddCar(car);

         

           

          
            
        }



        private void DeleteButton_Click(object sender, EventArgs e)
        {
            
        }

        private void SaveCars_Click(object sender, EventArgs e)
        {
            
        }

        private void CarImage_Click(object sender, EventArgs e)
        {

        }

        private void CarInventoryList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }

   
}
