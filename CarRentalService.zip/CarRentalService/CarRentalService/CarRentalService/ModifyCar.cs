﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentalService
{
    public partial class ModifyCar : Form
    {
        public ModifyCar()
        {
            InitializeComponent();
            this.FormClosed += ModifyCar_FormClosing;
        }

        private void ModifyCar_Load(object sender, EventArgs e)
        {
            DataTable carTable = carDatabase.loadFromCarDatabase();
            BindingSource bs = new BindingSource();
            bs.DataSource = carTable;

            CarInventoryDataGridView.DataSource = bs;
        }


        private void ModifyCar_FormClosing(object sender, FormClosedEventArgs e)
        {
            carDatabase carDatabase = new carDatabase();
            carDatabase.AddAllToDatabase(CarInventoryDataGridView);

        }

        private void Modbtn_Click(object sender, EventArgs e)
        {
            carDatabase.UpdateCarCategory(CarInventoryDataGridView, modBox, modifytxt);
        }

        private void homebtn_Click(object sender, EventArgs e)
        {
            this.Close();
            Mainfrm main = new Mainfrm();
            main.Show();
            
        }
    }
}
