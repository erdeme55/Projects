﻿
namespace CarRentalService
{
    partial class ModifyCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ModifyCar));
            this.CarInventoryDataGridView = new System.Windows.Forms.DataGridView();
            this.modBox = new System.Windows.Forms.ComboBox();
            this.modifytxt = new System.Windows.Forms.TextBox();
            this.Modbtn = new System.Windows.Forms.Button();
            this.homebtn = new System.Windows.Forms.Button();
            this.modIbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.CarInventoryDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // CarInventoryDataGridView
            // 
            this.CarInventoryDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CarInventoryDataGridView.Location = new System.Drawing.Point(44, 35);
            this.CarInventoryDataGridView.Name = "CarInventoryDataGridView";
            this.CarInventoryDataGridView.RowHeadersWidth = 51;
            this.CarInventoryDataGridView.RowTemplate.Height = 24;
            this.CarInventoryDataGridView.Size = new System.Drawing.Size(911, 222);
            this.CarInventoryDataGridView.TabIndex = 41;
            // 
            // modBox
            // 
            this.modBox.FormattingEnabled = true;
            this.modBox.Items.AddRange(new object[] {
            "CarCategory",
            "CarMake",
            "CarModel",
            "CarYear",
            "CarMilage",
            "CarRentalCost",
            "CarAvailability",
            "CarDescription",
            "CarLocation",
            "ImageURL"});
            this.modBox.Location = new System.Drawing.Point(265, 386);
            this.modBox.Name = "modBox";
            this.modBox.Size = new System.Drawing.Size(121, 24);
            this.modBox.TabIndex = 42;
            // 
            // modifytxt
            // 
            this.modifytxt.Location = new System.Drawing.Point(141, 388);
            this.modifytxt.Name = "modifytxt";
            this.modifytxt.Size = new System.Drawing.Size(100, 22);
            this.modifytxt.TabIndex = 43;
            // 
            // Modbtn
            // 
            this.Modbtn.Location = new System.Drawing.Point(193, 426);
            this.Modbtn.Name = "Modbtn";
            this.Modbtn.Size = new System.Drawing.Size(133, 54);
            this.Modbtn.TabIndex = 44;
            this.Modbtn.Text = "Click to Modify";
            this.Modbtn.UseVisualStyleBackColor = true;
            this.Modbtn.Click += new System.EventHandler(this.Modbtn_Click);
            // 
            // homebtn
            // 
            this.homebtn.Location = new System.Drawing.Point(775, 373);
            this.homebtn.Name = "homebtn";
            this.homebtn.Size = new System.Drawing.Size(180, 92);
            this.homebtn.TabIndex = 45;
            this.homebtn.Text = "Return to Home Page(form that contains inventory and search)";
            this.homebtn.UseVisualStyleBackColor = true;
            this.homebtn.Click += new System.EventHandler(this.homebtn_Click);
            // 
            // modIbl
            // 
            this.modIbl.AutoSize = true;
            this.modIbl.Location = new System.Drawing.Point(84, 290);
            this.modIbl.Name = "modIbl";
            this.modIbl.Size = new System.Drawing.Size(396, 68);
            this.modIbl.TabIndex = 46;
            this.modIbl.Text = resources.GetString("modIbl.Text");
            // 
            // ModifyCar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1022, 525);
            this.Controls.Add(this.modIbl);
            this.Controls.Add(this.homebtn);
            this.Controls.Add(this.Modbtn);
            this.Controls.Add(this.modifytxt);
            this.Controls.Add(this.modBox);
            this.Controls.Add(this.CarInventoryDataGridView);
            this.Name = "ModifyCar";
            this.Text = "ModifyCar";
            this.Load += new System.EventHandler(this.ModifyCar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.CarInventoryDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView CarInventoryDataGridView;
        private System.Windows.Forms.ComboBox modBox;
        private System.Windows.Forms.TextBox modifytxt;
        private System.Windows.Forms.Button Modbtn;
        private System.Windows.Forms.Button homebtn;
        private System.Windows.Forms.Label modIbl;
    }
}