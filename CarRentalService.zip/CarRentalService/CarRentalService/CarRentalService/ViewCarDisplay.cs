﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentalService
{
    public partial class ViewCarDisplay : Form
    {

        private Car car;
        public ViewCarDisplay(Car car)
        {
            InitializeComponent();
            this.car = car;


            categoryIbl.Text = car.CarCategory;
            makeIbl.Text = car.CarMake;
            modelIbl.Text = car.CarModel;
            yearcarIbl.Text = car.CarYear.ToString();
            milageIbl.Text = car.CarMilage.ToString();
            rentalIbl.Text = car.CarRentalCost.ToString();
            availableIbl.Text = car.CarAvailability;
            descripIbl.Text = car.CarDescription;
            locationIbl.Text = car.CarLocation;
            carPictureBox.ImageLocation = car.ImageURL;


        }

        private void ViewCarDisplay_Load(object sender, EventArgs e)
        {

        }
    }
}
