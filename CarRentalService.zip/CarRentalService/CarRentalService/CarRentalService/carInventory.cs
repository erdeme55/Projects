﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;



namespace CarRentalService
{
    class carInventory
    {
       
        private List<Car> carList;
        OleDbConnection myConnection;
        DataSet carDataSet;
        OleDbDataAdapter myDataAdapter;
        DataTable carTable;
        OleDbCommand carCommand;

        BindingSource myBinding;
        string carSQL;



        public carInventory()
        {
            carList = new List<Car>();
        }




        public List<Car> GetAllCars()
        {
            return carList;
        }

        public void AddCar(Car car)
        {
            carList.Add(car);
        }

        public void RemoveCar(Car car)
        {
            carList.Remove(car);
        }


    }
}
