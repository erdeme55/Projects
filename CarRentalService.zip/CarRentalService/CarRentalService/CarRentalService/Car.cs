﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRentalService
{
   public class Car
    {

        private string carCategory;
        private string carMake;
        private string carModel;
        private int carYear;
        private double carMilage;
        private double carRentalCost;
        private string carAvailability;
        private string carDescription;
        private string carLocation;
        private string URL;
        
        
      

        public Car()
        {
            

        }

        public Car(string carCategory, string carMake, string carModel, int carYear, double carMilage, double carRentalCost, string carAvailability, string carDescription, string carlocation, string imageURL)
        {
            this.carCategory = carCategory;
            this.carMake = carMake;
            this.carModel = carModel;
            this.carYear = carYear;
            this.carMilage = carMilage;
            this.carRentalCost = carRentalCost;
            this.carAvailability = carAvailability;
            this.carDescription = carDescription;
            this.carLocation = carlocation;
            this.URL = imageURL;
           

        }

        public string CarCategory
        {
            get { return carCategory; }
            set { carCategory = value; }
        }

        public string CarMake
        {
            get { return carMake; }
            set { carMake = value; }
        }

        public string CarModel
        {
            get { return carModel; }
            set { carModel = value; }
        }

        public int CarYear
        {
            get { return carYear; }
            set { carYear = value; }
        }

        public double CarMilage
        {
            get { return carMilage; }
            set { carMilage = value; }
        }

        public double CarRentalCost
        {
            get { return carRentalCost; }
            set { carRentalCost = value; }

        }

        public string CarAvailability
        {
            get { return carAvailability; }
            set { carAvailability = value; }
        }

        public string CarDescription
        {
            get { return carDescription; }
            set { carDescription = value; }
        }

        public string CarLocation
        {
            get { return carLocation; }
            set { carLocation = value; }
        }

       public string ImageURL
        {
            get { return URL; }
            set { URL = value; }
        }



    }
}
   