﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;

using System.Windows.Forms;
using System.Data.OleDb;

namespace CarRentalService
{
    class carDatabase
    {
        OleDbConnection myConnection;
        DataSet carDataSet;
        OleDbDataAdapter myDataAdapter;
         DataTable carTable;
        OleDbCommand carCommand;

       
        string carSQL;
        
        private List<Car> carList = new List<Car>();

        public carDatabase()
        {

        }


        public string addtoCarDatabase(Car car)
        {

            string addedVehicle = "added the vehicle to the table!";
            myConnection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=CarDB.accdb");
            myConnection.Open();
            carSQL = "INSERT INTO carDBTable (CarCategory, CarMake, CarModel, CarYear, CarMilage, CarRentalCost, CarAvailability, CarDescription, CarLocation, ImageURL) VALUES ('" + car.CarCategory + "', '" + car.CarMake + "', '" + car.CarModel + "', " + car.CarYear + ", " + car.CarMilage + ", " + car.CarRentalCost + ", '" + car.CarAvailability + "', '" + car.CarDescription + "', '" + car.CarLocation + "', '" + car.ImageURL + "') ";
            carCommand = new OleDbCommand(carSQL, myConnection);
            carDataSet = new DataSet("carTable");
            carCommand.ExecuteNonQuery();
            myConnection.Close();

            return addedVehicle;



        }


        public void AddAllToDatabase(DataGridView data)
        {
           

                myConnection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=CarDB.accdb");
                myConnection.Open();
                carSQL = "DELETE * FROM carDBTable";
                carCommand = new OleDbCommand(carSQL, myConnection);
                carCommand.ExecuteNonQuery();
                myConnection.Close();



                myConnection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=CarDB.accdb");
                myConnection.Open();
                carCommand = new OleDbCommand(carSQL, myConnection);

                foreach (DataGridViewRow row in data.Rows)
                {
                    if (row.Cells[1].Value != null)
                    {

                        string carCategory = row.Cells[1].Value.ToString();
                        string carMake = row.Cells[2].Value.ToString();
                        string carModel = row.Cells[3].Value.ToString();
                        string carYear = row.Cells[4].Value.ToString();
                        string carMilage = row.Cells[5].Value.ToString();
                        string carRentalCost = row.Cells[6].Value.ToString();
                        string carAvailability = row.Cells[7].Value.ToString();
                        string carDescription = row.Cells[8].Value.ToString();
                        string carLocation = row.Cells[9].Value.ToString();
                        string imageURL = row.Cells[10].Value.ToString();

                        carSQL = $"INSERT INTO carDBTable (CarCategory, CarMake, CarModel, CarYear, CarMilage, CarRentalCost, CarAvailability, CarDescription, CarLocation, ImageURL) VALUES ('{carCategory}', '{carMake}', '{carModel}', '{carYear}', '{carMilage}', '{carRentalCost}', '{carAvailability}', '{carDescription}', '{carLocation}','{imageURL}')";

                        carCommand = new OleDbCommand(carSQL, myConnection);
                        carCommand.ExecuteNonQuery();

                    }
                }
                myConnection.Close();

            
        }


        public static void UpdateCarCategory(DataGridView dataGridView, ComboBox comboBox, TextBox textBox)
        {
            if (dataGridView.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView.SelectedRows[0];
                string columnName = comboBox.SelectedItem.ToString();
                string newValue = textBox.Text;

              
                selectedRow.Cells[columnName].Value = newValue;
            }
        }


        public void DeleteFromDatabase(DataGridViewRow row)
        {
            myConnection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=CarDB.accdb");
            myConnection.Open();
            carSQL = "DELETE  FROM carDBTable WHERE ID =" + row.Cells[0].Value;
            carCommand = new OleDbCommand(carSQL, myConnection);
            carCommand.ExecuteNonQuery();
            myConnection.Close();
        }


       

        public static DataTable loadFromCarDatabase()
        {
          

            OleDbConnection myConnection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=CarDB.accdb");
            myConnection.Open();
            string carSQL = "SELECT * FROM carDBTable";

            OleDbDataAdapter myDataAdapter = new OleDbDataAdapter(carSQL, myConnection);
            DataTable carDataSet = new DataTable();
            myDataAdapter.Fill(carDataSet);

            myConnection.Close();

            return carDataSet;
        }

      

        public static void DisplaySelectedCarDetails(DataGridViewRow row)
        {
            
            string carCategory = row.Cells[1].Value.ToString();
            string carMake = row.Cells[2].Value.ToString();
            string carModel = row.Cells[3].Value.ToString();
            string carYear = row.Cells[4].Value.ToString();
            string carMilage = row.Cells[5].Value.ToString();
            string carRentalCost = row.Cells[6].Value.ToString();
            string carAvailability = row.Cells[7].Value.ToString();
            string carDescription = row.Cells[8].Value.ToString();
            string carLocation = row.Cells[9].Value.ToString();
            string imageURL = row.Cells[10].Value.ToString();

            Car car = new Car(carCategory, carMake, carModel,int.Parse(carYear), double.Parse(carMilage), double.Parse(carRentalCost), carAvailability, carDescription, carLocation, imageURL);

            ViewCarDisplay display = new ViewCarDisplay(car);
            display.Show();
        }



        public static void RemoveRows(DataGridView dataGridView)
        {
            foreach (DataGridViewRow row in dataGridView.SelectedRows)
            {
                dataGridView.Rows.Remove(row);
            }
        }



        public DataTable searchCarDatabase(string searchTerm)
        {
            myConnection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=CarDB.accdb;");
            carSQL = "SELECT * FROM carDBTable WHERE CarCategory = '" + searchTerm + "'";
            myDataAdapter = new OleDbDataAdapter(carSQL, myConnection);
            DataTable carDataSet = new DataTable();
            myDataAdapter.Fill(carDataSet);

            return carDataSet;
        }







    }
}
