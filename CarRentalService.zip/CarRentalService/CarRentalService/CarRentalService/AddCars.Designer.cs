﻿
namespace CarRentalService
{
    partial class AddCars
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GoBack = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.CarManufacturertxt = new System.Windows.Forms.TextBox();
            this.ModelOfCartxt = new System.Windows.Forms.TextBox();
            this.yeartxt = new System.Windows.Forms.TextBox();
            this.milagetxt = new System.Windows.Forms.TextBox();
            this.rentalcosttxt = new System.Windows.Forms.TextBox();
            this.descriptiontxt = new System.Windows.Forms.TextBox();
            this.locationtxt = new System.Windows.Forms.TextBox();
            this.CarCategorybox = new System.Windows.Forms.ComboBox();
            this.StoreInfo = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.manufacturerIbl = new System.Windows.Forms.Label();
            this.CarModelIbl = new System.Windows.Forms.Label();
            this.caryearIbl = new System.Windows.Forms.Label();
            this.carmilageIbl = new System.Windows.Forms.Label();
            this.carrentalcostIbl = new System.Windows.Forms.Label();
            this.caravailableIbl = new System.Windows.Forms.Label();
            this.descriptionIbl = new System.Windows.Forms.Label();
            this.locationIbl = new System.Windows.Forms.Label();
            this.availabletxt = new System.Windows.Forms.ComboBox();
            this.imagetxt = new System.Windows.Forms.TextBox();
            this.ImageIbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // GoBack
            // 
            this.GoBack.Location = new System.Drawing.Point(52, 554);
            this.GoBack.Name = "GoBack";
            this.GoBack.Size = new System.Drawing.Size(126, 42);
            this.GoBack.TabIndex = 0;
            this.GoBack.Text = "Back to Home Page";
            this.GoBack.UseVisualStyleBackColor = true;
            this.GoBack.Click += new System.EventHandler(this.GoBack_Click);
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(184, 554);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(114, 42);
            this.Exit.TabIndex = 1;
            this.Exit.Text = "Completely close program";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // CarManufacturertxt
            // 
            this.CarManufacturertxt.Location = new System.Drawing.Point(153, 13);
            this.CarManufacturertxt.Name = "CarManufacturertxt";
            this.CarManufacturertxt.Size = new System.Drawing.Size(100, 22);
            this.CarManufacturertxt.TabIndex = 2;
            // 
            // ModelOfCartxt
            // 
            this.ModelOfCartxt.Location = new System.Drawing.Point(153, 50);
            this.ModelOfCartxt.Name = "ModelOfCartxt";
            this.ModelOfCartxt.Size = new System.Drawing.Size(100, 22);
            this.ModelOfCartxt.TabIndex = 3;
            // 
            // yeartxt
            // 
            this.yeartxt.Location = new System.Drawing.Point(153, 91);
            this.yeartxt.Name = "yeartxt";
            this.yeartxt.Size = new System.Drawing.Size(100, 22);
            this.yeartxt.TabIndex = 4;
            // 
            // milagetxt
            // 
            this.milagetxt.Location = new System.Drawing.Point(153, 132);
            this.milagetxt.Name = "milagetxt";
            this.milagetxt.Size = new System.Drawing.Size(100, 22);
            this.milagetxt.TabIndex = 5;
            // 
            // rentalcosttxt
            // 
            this.rentalcosttxt.Location = new System.Drawing.Point(157, 182);
            this.rentalcosttxt.Name = "rentalcosttxt";
            this.rentalcosttxt.Size = new System.Drawing.Size(100, 22);
            this.rentalcosttxt.TabIndex = 6;
            // 
            // descriptiontxt
            // 
            this.descriptiontxt.Location = new System.Drawing.Point(153, 259);
            this.descriptiontxt.Name = "descriptiontxt";
            this.descriptiontxt.Size = new System.Drawing.Size(100, 22);
            this.descriptiontxt.TabIndex = 8;
            // 
            // locationtxt
            // 
            this.locationtxt.Location = new System.Drawing.Point(153, 305);
            this.locationtxt.Name = "locationtxt";
            this.locationtxt.Size = new System.Drawing.Size(100, 22);
            this.locationtxt.TabIndex = 9;
            // 
            // CarCategorybox
            // 
            this.CarCategorybox.FormattingEnabled = true;
            this.CarCategorybox.Items.AddRange(new object[] {
            "Economy",
            "Luxury",
            "Sport",
            "Supercar",
            "Sedan",
            "SUV",
            "Van",
            "Truck",
            "Coupe"});
            this.CarCategorybox.Location = new System.Drawing.Point(333, 390);
            this.CarCategorybox.Name = "CarCategorybox";
            this.CarCategorybox.Size = new System.Drawing.Size(121, 24);
            this.CarCategorybox.TabIndex = 11;
            // 
            // StoreInfo
            // 
            this.StoreInfo.Location = new System.Drawing.Point(52, 462);
            this.StoreInfo.Name = "StoreInfo";
            this.StoreInfo.Size = new System.Drawing.Size(173, 83);
            this.StoreInfo.TabIndex = 12;
            this.StoreInfo.Text = "Add car ";
            this.StoreInfo.UseVisualStyleBackColor = true;
            this.StoreInfo.Click += new System.EventHandler(this.StoreInfo_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 390);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(302, 17);
            this.label1.TabIndex = 13;
            this.label1.Text = "Please select car Category(ex. sport, suv, etc.)";
            // 
            // manufacturerIbl
            // 
            this.manufacturerIbl.AutoSize = true;
            this.manufacturerIbl.Location = new System.Drawing.Point(6, 16);
            this.manufacturerIbl.Name = "manufacturerIbl";
            this.manufacturerIbl.Size = new System.Drawing.Size(72, 17);
            this.manufacturerIbl.TabIndex = 14;
            this.manufacturerIbl.Text = "Car Make:";
            // 
            // CarModelIbl
            // 
            this.CarModelIbl.AutoSize = true;
            this.CarModelIbl.Location = new System.Drawing.Point(6, 55);
            this.CarModelIbl.Name = "CarModelIbl";
            this.CarModelIbl.Size = new System.Drawing.Size(76, 17);
            this.CarModelIbl.TabIndex = 15;
            this.CarModelIbl.Text = "Car Model:";
            // 
            // caryearIbl
            // 
            this.caryearIbl.AutoSize = true;
            this.caryearIbl.Location = new System.Drawing.Point(12, 96);
            this.caryearIbl.Name = "caryearIbl";
            this.caryearIbl.Size = new System.Drawing.Size(40, 17);
            this.caryearIbl.TabIndex = 16;
            this.caryearIbl.Text = "year:";
            // 
            // carmilageIbl
            // 
            this.carmilageIbl.AutoSize = true;
            this.carmilageIbl.Location = new System.Drawing.Point(6, 135);
            this.carmilageIbl.Name = "carmilageIbl";
            this.carmilageIbl.Size = new System.Drawing.Size(53, 17);
            this.carmilageIbl.TabIndex = 17;
            this.carmilageIbl.Text = "Milage:";
            // 
            // carrentalcostIbl
            // 
            this.carrentalcostIbl.AutoSize = true;
            this.carrentalcostIbl.Location = new System.Drawing.Point(2, 182);
            this.carrentalcostIbl.Name = "carrentalcostIbl";
            this.carrentalcostIbl.Size = new System.Drawing.Size(140, 17);
            this.carrentalcostIbl.TabIndex = 18;
            this.carrentalcostIbl.Text = "Rental Cost Per Day:";
            // 
            // caravailableIbl
            // 
            this.caravailableIbl.AutoSize = true;
            this.caravailableIbl.Location = new System.Drawing.Point(12, 224);
            this.caravailableIbl.Name = "caravailableIbl";
            this.caravailableIbl.Size = new System.Drawing.Size(69, 17);
            this.caravailableIbl.TabIndex = 19;
            this.caravailableIbl.Text = "Available:";
            // 
            // descriptionIbl
            // 
            this.descriptionIbl.AutoSize = true;
            this.descriptionIbl.Location = new System.Drawing.Point(6, 264);
            this.descriptionIbl.Name = "descriptionIbl";
            this.descriptionIbl.Size = new System.Drawing.Size(123, 17);
            this.descriptionIbl.TabIndex = 20;
            this.descriptionIbl.Text = "Description of car:";
            // 
            // locationIbl
            // 
            this.locationIbl.AutoSize = true;
            this.locationIbl.Location = new System.Drawing.Point(6, 310);
            this.locationIbl.Name = "locationIbl";
            this.locationIbl.Size = new System.Drawing.Size(113, 17);
            this.locationIbl.TabIndex = 21;
            this.locationIbl.Text = "Location On Lot:";
            // 
            // availabletxt
            // 
            this.availabletxt.FormattingEnabled = true;
            this.availabletxt.Items.AddRange(new object[] {
            "Available",
            "Rented"});
            this.availabletxt.Location = new System.Drawing.Point(157, 224);
            this.availabletxt.Name = "availabletxt";
            this.availabletxt.Size = new System.Drawing.Size(121, 24);
            this.availabletxt.TabIndex = 22;
            // 
            // imagetxt
            // 
            this.imagetxt.Location = new System.Drawing.Point(153, 349);
            this.imagetxt.Name = "imagetxt";
            this.imagetxt.Size = new System.Drawing.Size(100, 22);
            this.imagetxt.TabIndex = 23;
            // 
            // ImageIbl
            // 
            this.ImageIbl.AutoSize = true;
            this.ImageIbl.Location = new System.Drawing.Point(15, 353);
            this.ImageIbl.Name = "ImageIbl";
            this.ImageIbl.Size = new System.Drawing.Size(82, 17);
            this.ImageIbl.TabIndex = 24;
            this.ImageIbl.Text = "Image URL:";
            // 
            // AddCars
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(552, 605);
            this.Controls.Add(this.ImageIbl);
            this.Controls.Add(this.imagetxt);
            this.Controls.Add(this.availabletxt);
            this.Controls.Add(this.locationIbl);
            this.Controls.Add(this.descriptionIbl);
            this.Controls.Add(this.caravailableIbl);
            this.Controls.Add(this.carrentalcostIbl);
            this.Controls.Add(this.carmilageIbl);
            this.Controls.Add(this.caryearIbl);
            this.Controls.Add(this.CarModelIbl);
            this.Controls.Add(this.manufacturerIbl);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.StoreInfo);
            this.Controls.Add(this.CarCategorybox);
            this.Controls.Add(this.locationtxt);
            this.Controls.Add(this.descriptiontxt);
            this.Controls.Add(this.rentalcosttxt);
            this.Controls.Add(this.milagetxt);
            this.Controls.Add(this.yeartxt);
            this.Controls.Add(this.ModelOfCartxt);
            this.Controls.Add(this.CarManufacturertxt);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.GoBack);
            this.Name = "AddCars";
            this.Text = "AddCars";
            this.Load += new System.EventHandler(this.AddCars_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button GoBack;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.TextBox CarManufacturertxt;
        private System.Windows.Forms.TextBox ModelOfCartxt;
        private System.Windows.Forms.TextBox yeartxt;
        private System.Windows.Forms.TextBox milagetxt;
        private System.Windows.Forms.TextBox rentalcosttxt;
        private System.Windows.Forms.TextBox descriptiontxt;
        private System.Windows.Forms.TextBox locationtxt;
        private System.Windows.Forms.ComboBox CarCategorybox;
        private System.Windows.Forms.Button StoreInfo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label manufacturerIbl;
        private System.Windows.Forms.Label CarModelIbl;
        private System.Windows.Forms.Label caryearIbl;
        private System.Windows.Forms.Label carmilageIbl;
        private System.Windows.Forms.Label carrentalcostIbl;
        private System.Windows.Forms.Label caravailableIbl;
        private System.Windows.Forms.Label descriptionIbl;
        private System.Windows.Forms.Label locationIbl;
        private System.Windows.Forms.ComboBox availabletxt;
        private System.Windows.Forms.TextBox imagetxt;
        private System.Windows.Forms.Label ImageIbl;
    }
}