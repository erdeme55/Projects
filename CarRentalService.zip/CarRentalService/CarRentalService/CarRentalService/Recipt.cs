﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace CarRentalService
{
    public partial class Recipt : Form
    {
       private Car car;
        private CustomerInfo customer;
        private RentalCost rental;




        public Recipt(CustomerInfo customer, RentalCost rental, Car car)
        {
            InitializeComponent();
            this.customer = customer;
            this.rental = rental;
            this.car = car;
           
            

            firstnameIbl.Text = customer.FirstName;
            lastnameIbl.Text = customer.LastName;
            phonenumberIbl.Text = customer.PhoneNumber;
            driversidIbl.Text = customer.DriversIdNumber;
            insuranceIbl.Text = customer.InsuranceInfo;
            daysrentedIbl.Text = rental.RentalDays.ToString();
            addedTaxIbl.Text = rental.TaxAmount.ToString();
            totalcostIbl.Text = rental.TotalCost.ToString();
            DOBIbl.Text = customer.DateOfBirth;
            addressIbl.Text = customer.AddressLocation;
            carPictureBox.ImageLocation = car.ImageURL;




        }

        private void Recipt_Load(object sender, EventArgs e)
        {

           
           
        }
    }
}
