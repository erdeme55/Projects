﻿
namespace CarRentalService
{
    partial class Mainfrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AddCars = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.RentCar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.CarInventoryDataGridView = new System.Windows.Forms.DataGridView();
            this.searchCarCategory = new System.Windows.Forms.ComboBox();
            this.searchCategory = new System.Windows.Forms.Button();
            this.carcatIbl = new System.Windows.Forms.Label();
            this.deleteBtn = new System.Windows.Forms.Button();
            this.deleteIbl = new System.Windows.Forms.Label();
            this.viewbtn = new System.Windows.Forms.Button();
            this.viewIbl = new System.Windows.Forms.Label();
            this.modbtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.carBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carDBDataSet = new CarRentalService.CarDBDataSet();
            this.carDBTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carDBTableTableAdapter = new CarRentalService.CarDBDataSetTableAdapters.CarDBTableTableAdapter();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.carCategoryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.carMakeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.carModelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.carYearDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.carMilageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.carRentalCostDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.carAvailabilityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.carDescriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.carLocationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.imageURLDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.CarInventoryDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carDBTableBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // AddCars
            // 
            this.AddCars.Location = new System.Drawing.Point(12, 118);
            this.AddCars.Name = "AddCars";
            this.AddCars.Size = new System.Drawing.Size(128, 59);
            this.AddCars.TabIndex = 1;
            this.AddCars.Text = "Add Cars";
            this.AddCars.UseVisualStyleBackColor = true;
            this.AddCars.Click += new System.EventHandler(this.AddCars_Click);
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(12, 460);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(108, 53);
            this.Exit.TabIndex = 3;
            this.Exit.Text = "Exit out of service";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // RentCar
            // 
            this.RentCar.Location = new System.Drawing.Point(12, 194);
            this.RentCar.Name = "RentCar";
            this.RentCar.Size = new System.Drawing.Size(128, 63);
            this.RentCar.TabIndex = 4;
            this.RentCar.Text = "Rent a Car";
            this.RentCar.UseVisualStyleBackColor = true;
            this.RentCar.Click += new System.EventHandler(this.RentCar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(384, 34);
            this.label1.TabIndex = 9;
            this.label1.Text = "Welcome to the car rental Service! \r\nPlease pick one of the buttons below to do o" +
    "ne of the tasks:";
            // 
            // CarInventoryDataGridView
            // 
            this.CarInventoryDataGridView.AutoGenerateColumns = false;
            this.CarInventoryDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CarInventoryDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.carCategoryDataGridViewTextBoxColumn,
            this.carMakeDataGridViewTextBoxColumn,
            this.carModelDataGridViewTextBoxColumn,
            this.carYearDataGridViewTextBoxColumn,
            this.carMilageDataGridViewTextBoxColumn,
            this.carRentalCostDataGridViewTextBoxColumn,
            this.carAvailabilityDataGridViewTextBoxColumn,
            this.carDescriptionDataGridViewTextBoxColumn,
            this.carLocationDataGridViewTextBoxColumn,
            this.imageURLDataGridViewTextBoxColumn});
            this.CarInventoryDataGridView.DataSource = this.carDBTableBindingSource;
            this.CarInventoryDataGridView.Location = new System.Drawing.Point(614, 70);
            this.CarInventoryDataGridView.Name = "CarInventoryDataGridView";
            this.CarInventoryDataGridView.RowHeadersWidth = 51;
            this.CarInventoryDataGridView.RowTemplate.Height = 24;
            this.CarInventoryDataGridView.Size = new System.Drawing.Size(838, 434);
            this.CarInventoryDataGridView.TabIndex = 26;
            // 
            // searchCarCategory
            // 
            this.searchCarCategory.FormattingEnabled = true;
            this.searchCarCategory.Items.AddRange(new object[] {
            "Economy ",
            "Sport ",
            "Luxury",
            "SuperCar",
            "Sedan",
            "SUV",
            "Coupe",
            "Truck",
            "Van",
            "Hatchback",
            "Convertible"});
            this.searchCarCategory.Location = new System.Drawing.Point(853, 554);
            this.searchCarCategory.Name = "searchCarCategory";
            this.searchCarCategory.Size = new System.Drawing.Size(121, 24);
            this.searchCarCategory.TabIndex = 28;
            // 
            // searchCategory
            // 
            this.searchCategory.Location = new System.Drawing.Point(995, 535);
            this.searchCategory.Name = "searchCategory";
            this.searchCategory.Size = new System.Drawing.Size(150, 60);
            this.searchCategory.TabIndex = 29;
            this.searchCategory.Text = "Search by car Category(Type)";
            this.searchCategory.UseVisualStyleBackColor = true;
            this.searchCategory.Click += new System.EventHandler(this.searchCategory_Click);
            // 
            // carcatIbl
            // 
            this.carcatIbl.AutoSize = true;
            this.carcatIbl.Location = new System.Drawing.Point(649, 554);
            this.carcatIbl.Name = "carcatIbl";
            this.carcatIbl.Size = new System.Drawing.Size(198, 34);
            this.carcatIbl.TabIndex = 30;
            this.carcatIbl.Text = "Search for car category(type) \r\nyou are interested in";
            // 
            // deleteBtn
            // 
            this.deleteBtn.Location = new System.Drawing.Point(12, 287);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(128, 60);
            this.deleteBtn.TabIndex = 31;
            this.deleteBtn.Text = "Delete Car";
            this.deleteBtn.UseVisualStyleBackColor = true;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // deleteIbl
            // 
            this.deleteIbl.AutoSize = true;
            this.deleteIbl.Location = new System.Drawing.Point(9, 360);
            this.deleteIbl.Name = "deleteIbl";
            this.deleteIbl.Size = new System.Drawing.Size(262, 51);
            this.deleteIbl.TabIndex = 32;
            this.deleteIbl.Text = "Choose the row of the car that you want \r\nto delete from the data inventory then " +
    "\r\nclick the \"Delete\" button\r\n";
            // 
            // viewbtn
            // 
            this.viewbtn.Location = new System.Drawing.Point(477, 204);
            this.viewbtn.Name = "viewbtn";
            this.viewbtn.Size = new System.Drawing.Size(113, 42);
            this.viewbtn.TabIndex = 33;
            this.viewbtn.Text = "View Car";
            this.viewbtn.UseVisualStyleBackColor = true;
            this.viewbtn.Click += new System.EventHandler(this.viewbtn_Click);
            // 
            // viewIbl
            // 
            this.viewIbl.AutoSize = true;
            this.viewIbl.Location = new System.Drawing.Point(310, 155);
            this.viewIbl.Name = "viewIbl";
            this.viewIbl.Size = new System.Drawing.Size(261, 34);
            this.viewIbl.TabIndex = 35;
            this.viewIbl.Text = "press \"View car\" button to view car data \r\nof selected row in datagrid";
            // 
            // modbtn
            // 
            this.modbtn.Location = new System.Drawing.Point(477, 286);
            this.modbtn.Name = "modbtn";
            this.modbtn.Size = new System.Drawing.Size(113, 61);
            this.modbtn.TabIndex = 36;
            this.modbtn.Text = " Modify cars info\r\n";
            this.modbtn.UseVisualStyleBackColor = true;
            this.modbtn.Click += new System.EventHandler(this.modbtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(400, 360);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(208, 85);
            this.label2.TabIndex = 37;
            this.label2.Text = "Click the modify cars info button\r\nright above this label message\r\nto go to a dif" +
    "ferent form to be\r\nable to modify car data about\r\na chosen car";
            // 
            // carBindingSource
            // 
            this.carBindingSource.DataMember = "car";
            // 
            // carDBDataSet
            // 
            this.carDBDataSet.DataSetName = "CarDBDataSet";
            this.carDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // carDBTableBindingSource
            // 
            this.carDBTableBindingSource.DataMember = "CarDBTable";
            this.carDBTableBindingSource.DataSource = this.carDBDataSet;
            // 
            // carDBTableTableAdapter
            // 
            this.carDBTableTableAdapter.ClearBeforeFill = true;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.Width = 125;
            // 
            // carCategoryDataGridViewTextBoxColumn
            // 
            this.carCategoryDataGridViewTextBoxColumn.DataPropertyName = "CarCategory";
            this.carCategoryDataGridViewTextBoxColumn.HeaderText = "CarCategory";
            this.carCategoryDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.carCategoryDataGridViewTextBoxColumn.Name = "carCategoryDataGridViewTextBoxColumn";
            this.carCategoryDataGridViewTextBoxColumn.Visible = false;
            this.carCategoryDataGridViewTextBoxColumn.Width = 125;
            // 
            // carMakeDataGridViewTextBoxColumn
            // 
            this.carMakeDataGridViewTextBoxColumn.DataPropertyName = "CarMake";
            this.carMakeDataGridViewTextBoxColumn.HeaderText = "CarMake";
            this.carMakeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.carMakeDataGridViewTextBoxColumn.Name = "carMakeDataGridViewTextBoxColumn";
            this.carMakeDataGridViewTextBoxColumn.Width = 125;
            // 
            // carModelDataGridViewTextBoxColumn
            // 
            this.carModelDataGridViewTextBoxColumn.DataPropertyName = "CarModel";
            this.carModelDataGridViewTextBoxColumn.HeaderText = "CarModel";
            this.carModelDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.carModelDataGridViewTextBoxColumn.Name = "carModelDataGridViewTextBoxColumn";
            this.carModelDataGridViewTextBoxColumn.Width = 125;
            // 
            // carYearDataGridViewTextBoxColumn
            // 
            this.carYearDataGridViewTextBoxColumn.DataPropertyName = "CarYear";
            this.carYearDataGridViewTextBoxColumn.HeaderText = "CarYear";
            this.carYearDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.carYearDataGridViewTextBoxColumn.Name = "carYearDataGridViewTextBoxColumn";
            this.carYearDataGridViewTextBoxColumn.Width = 125;
            // 
            // carMilageDataGridViewTextBoxColumn
            // 
            this.carMilageDataGridViewTextBoxColumn.DataPropertyName = "CarMilage";
            this.carMilageDataGridViewTextBoxColumn.HeaderText = "CarMilage";
            this.carMilageDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.carMilageDataGridViewTextBoxColumn.Name = "carMilageDataGridViewTextBoxColumn";
            this.carMilageDataGridViewTextBoxColumn.Visible = false;
            this.carMilageDataGridViewTextBoxColumn.Width = 125;
            // 
            // carRentalCostDataGridViewTextBoxColumn
            // 
            this.carRentalCostDataGridViewTextBoxColumn.DataPropertyName = "CarRentalCost";
            this.carRentalCostDataGridViewTextBoxColumn.HeaderText = "CarRentalCost";
            this.carRentalCostDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.carRentalCostDataGridViewTextBoxColumn.Name = "carRentalCostDataGridViewTextBoxColumn";
            this.carRentalCostDataGridViewTextBoxColumn.Width = 125;
            // 
            // carAvailabilityDataGridViewTextBoxColumn
            // 
            this.carAvailabilityDataGridViewTextBoxColumn.DataPropertyName = "CarAvailability";
            this.carAvailabilityDataGridViewTextBoxColumn.HeaderText = "CarAvailability";
            this.carAvailabilityDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.carAvailabilityDataGridViewTextBoxColumn.Name = "carAvailabilityDataGridViewTextBoxColumn";
            this.carAvailabilityDataGridViewTextBoxColumn.Width = 125;
            // 
            // carDescriptionDataGridViewTextBoxColumn
            // 
            this.carDescriptionDataGridViewTextBoxColumn.DataPropertyName = "CarDescription";
            this.carDescriptionDataGridViewTextBoxColumn.HeaderText = "CarDescription";
            this.carDescriptionDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.carDescriptionDataGridViewTextBoxColumn.Name = "carDescriptionDataGridViewTextBoxColumn";
            this.carDescriptionDataGridViewTextBoxColumn.Visible = false;
            this.carDescriptionDataGridViewTextBoxColumn.Width = 125;
            // 
            // carLocationDataGridViewTextBoxColumn
            // 
            this.carLocationDataGridViewTextBoxColumn.DataPropertyName = "CarLocation";
            this.carLocationDataGridViewTextBoxColumn.HeaderText = "CarLocation";
            this.carLocationDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.carLocationDataGridViewTextBoxColumn.Name = "carLocationDataGridViewTextBoxColumn";
            this.carLocationDataGridViewTextBoxColumn.Visible = false;
            this.carLocationDataGridViewTextBoxColumn.Width = 125;
            // 
            // imageURLDataGridViewTextBoxColumn
            // 
            this.imageURLDataGridViewTextBoxColumn.DataPropertyName = "ImageURL";
            this.imageURLDataGridViewTextBoxColumn.HeaderText = "ImageURL";
            this.imageURLDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.imageURLDataGridViewTextBoxColumn.Name = "imageURLDataGridViewTextBoxColumn";
            this.imageURLDataGridViewTextBoxColumn.Visible = false;
            this.imageURLDataGridViewTextBoxColumn.Width = 125;
            // 
            // Mainfrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1607, 650);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.modbtn);
            this.Controls.Add(this.viewIbl);
            this.Controls.Add(this.viewbtn);
            this.Controls.Add(this.deleteIbl);
            this.Controls.Add(this.deleteBtn);
            this.Controls.Add(this.carcatIbl);
            this.Controls.Add(this.searchCategory);
            this.Controls.Add(this.searchCarCategory);
            this.Controls.Add(this.CarInventoryDataGridView);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.RentCar);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.AddCars);
            this.Name = "Mainfrm";
            this.Text = "Main form(also the form containing Inventory List of cars)";
            this.Load += new System.EventHandler(this.Mainfrm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.CarInventoryDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carDBTableBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button AddCars;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Button RentCar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView CarInventoryDataGridView;
        private System.Windows.Forms.ComboBox searchCarCategory;
        private System.Windows.Forms.Button searchCategory;
        private System.Windows.Forms.Label carcatIbl;
        private System.Windows.Forms.Button deleteBtn;
        private System.Windows.Forms.Label deleteIbl;
        private System.Windows.Forms.Button viewbtn;
        private System.Windows.Forms.Label viewIbl;
        private System.Windows.Forms.Button modbtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.BindingSource carBindingSource;
        private CarDBDataSet carDBDataSet;
        private System.Windows.Forms.BindingSource carDBTableBindingSource;
        private CarDBDataSetTableAdapters.CarDBTableTableAdapter carDBTableTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn carCategoryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn carMakeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn carModelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn carYearDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn carMilageDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn carRentalCostDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn carAvailabilityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn carDescriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn carLocationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn imageURLDataGridViewTextBoxColumn;
    }
}

